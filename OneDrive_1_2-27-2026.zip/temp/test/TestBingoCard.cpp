/**
 * @author L. Nicole Wilson [n.wilson@uleth.ca], J. Anvik [john.anvik@uleth.ca]
 * @date 2023-09
 */
#include <string>
#include <vector>

#include "BingoCard.h"
#include "BingoTypes.h"
#include "Square.h"
#include "VictoryCondition.h"
#include "Exceptions.h"
#include "gtest/gtest.h"

TEST(TestBingoCard, defaultConstructorTest) {
  BingoCard bc;

  BingoTypes::squarePos pos;
  pos.row = 1;
  pos.col = 1;
  EXPECT_EQ(bc.getGameType(), BingoTypes::BINGO75);
  EXPECT_THROW(bc.typesMatch(BingoTypes::BINGO75, BingoTypes::BLACKOUT),
               incomplete_settings);
  EXPECT_THROW(bc.daubSquare(10, pos), incomplete_settings);
  EXPECT_THROW(bc.isCorrect(), incomplete_settings);
  EXPECT_THROW(bc.isVictorious(), incomplete_settings);
  EXPECT_THROW(bc.getVictoryType(), incomplete_settings);
}

TEST(TestBingoCard, oneParamConstructorTest) {
  BingoCard bc(BingoTypes::BINGO50);

  BingoTypes::squarePos pos;
  pos.row = 1;
  pos.col = 1;

  EXPECT_EQ(bc.getGameType(), BingoTypes::BINGO50);
  EXPECT_THROW(bc.typesMatch(BingoTypes::BINGO50, BingoTypes::BLACKOUT),
               incomplete_settings);
  EXPECT_THROW(bc.daubSquare(10, pos), incomplete_settings);
  EXPECT_THROW(bc.isCorrect(), incomplete_settings);
  EXPECT_THROW(bc.isVictorious(), incomplete_settings);
  EXPECT_THROW(bc.getVictoryType(), incomplete_settings);
}

TEST(TestBingoCard, checkGridValidityTest){
  std::vector<Square*> grid;
  BingoCard *card = new BingoCard(BingoTypes::BINGO50);
  grid.clear();

  EXPECT_THROW(card->setGrid(grid),incomplete_settings);
  // grid.push_back(new IntSquare(4));
  // EXPECT_THROW(card->setGrid(grid),invalid_size);
  grid.clear();
  for ( int i = 0; i <= 4; i++ ) {
    for ( int j = 1; j <= 5; j++ ) {
      if( i == 2 && j == 3) {
        grid.push_back(new FreeSquare());
      }
      else grid.push_back(new IntSquare(i*10 + j));
    }
  }
  EXPECT_NO_THROW(card->setGrid(grid));
  delete grid[0];
  grid[0] = new IntSquare(32);
  EXPECT_THROW(card->setGrid(grid), card_to_game_mismatch);
  delete grid[0];

  grid[0] = new IntSquare(2);
  EXPECT_THROW(card->setGrid(grid),bad_input);
  delete grid[0];
  grid[0] = nullptr;

  for ( int i = 0; i < grid.size();i++){
    delete grid[i];
    grid[i] = nullptr;
  }
  grid.clear();
  // card = nullptr;
  // delete card;
  // card = nullptr;
}

TEST(TestBingoCard, daubSquareTest) {
  std::vector<Square*> grid;
  for ( int i = 0; i <= 4; i++ ) {
    for ( int j = 1; j <= 5; j++ ) {
      if( i == 2 && j == 3) {
        grid.push_back(new FreeSquare());
      }
      else grid.push_back(new IntSquare(i*10 + j));
    }
  }
  BingoCard *card = new BingoCard(grid,BingoTypes::BINGO50);
  BingoTypes::squarePos pos;
  pos.row = 1;
  pos.col = 4;

  EXPECT_EQ(card->daubSquare(4,pos),true);
  EXPECT_EQ(card->daubSquare(4,pos),false);
  pos.row = 3;
  pos.col = 1;
  EXPECT_EQ(card->daubSquare(1,pos),true);
  EXPECT_EQ(card->daubSquare(1,pos),false);

  delete card;

  // for ( int i = 0; i < grid.size();i++){
  //   delete grid[i];
  //   grid[i] = nullptr;
  // }
  grid.clear();
}

TEST(TestBingoCard, getGameTypeTest) {
  BingoCard *card = new BingoCard();
  EXPECT_EQ(card->getGameType(),BingoTypes::BINGO75);
  delete card;
  card = new BingoCard(BingoTypes::BINGO50);
  EXPECT_EQ(card->getGameType(),BingoTypes::BINGO50);
  delete card;
  card = nullptr;
}

TEST(TestBingoCard, getSquareTest) {
  std::vector<Square*> grid;
  for ( int i = 0; i <= 4; i++ ) {
    for ( int j = 1; j <= 5; j++ ) {
      if( i == 2 && j == 3) {
        grid.push_back(new FreeSquare());
      }
      else grid.push_back(new IntSquare(i*10 + j));
    }
  }
  BingoCard* card = new BingoCard(grid,BingoTypes::BINGO50);
  BingoTypes::squarePos pos;
  pos.row = 2;
  pos.col = 4;
  EXPECT_EQ(card->getSquare(pos)->getValue(),32);
  delete card;
  // for ( int i = 0; i < grid.size();i++){
  //   delete grid[i];
  //   grid[i] = nullptr;
  // }
  // grid.clear();
}

TEST(TestBingoCard, VictoryTypeTest) {
  BingoCard* card = new BingoCard();

  EXPECT_THROW(card->getVictoryType(),incomplete_settings);
  EXPECT_THROW(card->setVictoryCondition(nullptr),bad_input);

  EXPECT_NO_THROW(card->setVictoryCondition(new HorizontalLine()));
  card->setVictoryCondition(new HorizontalLine());
  EXPECT_EQ(card->getVictoryType(),BingoTypes::HORIZONTAL_LINE);
  delete card;
  card = nullptr;
}

TEST(TestBingoCard, isCorrectTest) {
  std::vector<Square*> grid;
  for ( int i = 0; i <= 4; i++ ) {
    for ( int j = 1; j <= 5; j++ ) {
      if( i == 2 && j == 3) {
        grid.push_back(new FreeSquare());
      }
      else grid.push_back(new IntSquare(i*10 + j));
    }
  }
  BingoCard* card = new BingoCard(grid,BingoTypes::BINGO50);

  EXPECT_EQ(card->isCorrect(),true);

  BingoTypes::squarePos pos;
  pos.row = 4;
  pos.col = 1;

  card->daubSquare(4,pos);
  EXPECT_EQ(card->isCorrect(),true);

  pos.row = 3;
  card->daubSquare(1,pos);
  EXPECT_EQ(card->isCorrect(),false);

  delete card;

  // for ( int i = 0; i < grid.size();i++){
  //   delete grid[i];
  //   grid[i] = nullptr;
  // }
  // grid.clear();
}

TEST(TestBingoCard, isVictoriousTest) {
  std::vector<Square*> grid;
  for ( int i = 0; i <= 4; i++ ) {
    for ( int j = 1; j <= 5; j++ ) {
      if( i == 2 && j == 3) {
        grid.push_back(new FreeSquare());
      }
      else grid.push_back(new IntSquare(i*10 + j));
    }
  }
  BingoCard* card = new BingoCard(grid,BingoTypes::BINGO50);

  BingoTypes::squarePos pos;
  pos.row = 1;
  pos.col = 1;

for ( int i = 0; i <= 4; i++ ) {
  pos.row = i+1;
    for ( int j = 1; j <= 5; j++ ) {
      pos.col = j;
      if( i == 2 && j == 3) {
        continue;
        card->daubSquare(0,pos);
      }
      else card->daubSquare(i*10+j,pos); 
    }
  }

  EXPECT_THROW(card->isVictorious(),incomplete_settings);
  card->setVictoryCondition(new HorizontalLine());
  EXPECT_EQ(card->isVictorious(),true);

  card->setVictoryCondition(new VerticalLine());
  EXPECT_EQ(card->isVictorious(),true);
  
  card->setVictoryCondition(new AnyLine());
  EXPECT_EQ(card->isVictorious(),true);
  
  // VictoryCondition *b = new Blackout();
  // card->setVictoryCondition(b);
  // EXPECT_EQ(card->isVictorious(),true);

  delete card;

  // for(auto i : grid) {
  //   delete i;
  //   i = nullptr;
  // }
  // delete card;
  // card = nullptr;
}

TEST(TestBingoCard, resetCardTest){
  std::vector<Square*> grid;
  for ( int i = 0; i <= 4; i++ ) {
    for ( int j = 1; j <= 5; j++ ) {
      if( i == 2 && j == 3) {
        grid.push_back(new FreeSquare());
      }
      else grid.push_back(new IntSquare(i*10 + j));
    }
  }
  BingoCard* card = new BingoCard(grid,BingoTypes::BINGO50);
  BingoTypes::squarePos pos;
  pos.col = 1;
  pos.row = 1;

  card->daubSquare(1,pos);
  card->resetCard();

  EXPECT_EQ(card->getSquare(pos)->getDaubState()->isDaubed(),false);

  delete card;

  // for(int i = 0; i< grid.size();i++) {
  //   delete grid[i];
  //   grid[i] = nullptr;
  // }
  // grid.clear();
}

TEST(TestBingoCard, typesMatchTest){
  std::vector<Square*> grid;
  for ( int i = 0; i <= 4; i++ ) {
    for ( int j = 1; j <= 5; j++ ) {
      if( i == 2 && j == 3) {
        grid.push_back(new FreeSquare());
      }
      else grid.push_back(new IntSquare(i*10 + j));
    }
  }
  BingoCard* card = new BingoCard(grid,BingoTypes::BINGO50);

  VictoryCondition *v = new AnyLine();
  EXPECT_THROW(card->typesMatch(BingoTypes::BINGO50,BingoTypes::ANY_LINE),incomplete_settings);
  card->setVictoryCondition(v);
  EXPECT_EQ(card->typesMatch(BingoTypes::BINGO50,BingoTypes::ANY_LINE),true);
  EXPECT_EQ(card->typesMatch(BingoTypes::BINGO75,BingoTypes::ANY_LINE),false);
  EXPECT_EQ(card->typesMatch(BingoTypes::BINGO50,BingoTypes::VERTICAL_LINE),false);

  delete card;

  // for ( int i = 0; i < grid.size();i++){
  //   delete grid[i];
  //   grid[i] = nullptr;
  // }
  // grid.clear();
}
