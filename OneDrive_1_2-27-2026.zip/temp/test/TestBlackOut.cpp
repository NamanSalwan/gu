#include <string>
#include <vector>

#include "gtest/gtest.h"
#include "BingoTypes.h"
#include "VictoryCondition.h"
#include "Square.h"

TEST(TestBlackout, constructionTest) {
  VictoryCondition* victory = new Blackout();

  std::string expectedDesc = "Daub all squares on the card.";
  
  EXPECT_EQ(victory->getDescription(), expectedDesc);
  EXPECT_EQ(victory->getVictoryType(), BingoTypes::BLACKOUT);

  delete victory;
}

TEST(TestBlackout, hasWonTest){
  VictoryCondition* victory = new Blackout();
  std::vector<Square*> grid;
  for(int i = 0 ;i < 25;i++) {
    if(i == 12 ) grid.push_back(new FreeSquare());
    else grid.push_back(new IntSquare(i+1));
  }

  EXPECT_EQ(victory->hasWon(grid),false);

  for(int i = 0;i<25;i++){
    if( i == 10) continue;
    grid[i]->daubSquare(i+1);
  }

  EXPECT_EQ(victory->hasWon(grid),false);
  grid[10]->daubSquare(11);
  EXPECT_EQ(victory->hasWon(grid),true);
  for(auto i : grid) delete i;
  delete victory;
}