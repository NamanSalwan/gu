/**
* @author L. Nicole Wilson [n.wilson@uleth.ca]
* @date 2023-09
*/
/*
#include <string>
#include <vector>

#include "gtest/gtest.h"
#include "BingoTypes.h"
#include "VictoryCondition.h"
#include "Square.h"

TEST(TestVerticalLine, constructionTest) {
  VictoryCondition* victory = new VerticalLine();

  std::string expectedDesc = "Daub five squares in a vertical line.";
  
  EXPECT_EQ(victory->getDescription(), expectedDesc);
  EXPECT_EQ(victory->getVictoryType(), BingoTypes::VERTICAL_LINE);

  delete victory;
}

TEST(TestVerticalLine, checkSquareSetTest) {
  std::vector<Square*> grid;
  for(int i = 0 ;i < 25;i++) {
    if(i == 12 ) grid.push_back(new FreeSquare());
    else grid.push_back(new IntSquare(i+1));
  }
  for(int i = 10;i<14;i++){
    grid[i]->daubSquare(i+1);
  }

  VictoryCondition* victory = new VerticalLine();
  EXPECT_EQ(victory->hasWon(grid),false);

  grid[14]->daubSquare(16);
  EXPECT_EQ(victory->hasWon(grid),false);
  grid[14]->daubSquare(15);
  EXPECT_EQ(victory->hasWon(grid),true);
  delete victory;

  for(auto i : grid) {
    delete i;
    i = nullptr;
  }
  grid.clear();
}
*/
