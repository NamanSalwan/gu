#include <string>
#include <vector>

#include "gtest/gtest.h"
#include "BingoTypes.h"
#include "VictoryCondition.h"
#include "Square.h"

TEST(TestHorizontalLine, constructionTest) {
  VictoryCondition* victory = new HorizontalLine();

  std::string expectedDesc = "Daub five squares in a horizontal line.";
  
  EXPECT_EQ(victory->getDescription(), expectedDesc);
  EXPECT_EQ(victory->getVictoryType(), BingoTypes::HORIZONTAL_LINE);

  delete victory;
}

TEST(TestHorizontalLine, hasWonTest){
  VictoryCondition* victory = new HorizontalLine();
  std::vector<Square*> grid;
  for(int i = 0 ;i < 25;i++) {
    if(i == 12 ) grid.push_back(new FreeSquare());
    else grid.push_back(new IntSquare(i+1));
  }
  for(int i = 10;i<14;i++){
    grid[i]->daubSquare(i+1);
  }
  EXPECT_EQ(victory->hasWon(grid),false);

  for(int i = 0;i<4;i++){
    grid[5*i]->daubSquare(5*i+1);
  }

  EXPECT_EQ(victory->hasWon(grid),false);
  grid[20]->daubSquare(21);
  EXPECT_EQ(victory->hasWon(grid),true);
  for(auto i : grid) delete i;
  delete victory;
}
