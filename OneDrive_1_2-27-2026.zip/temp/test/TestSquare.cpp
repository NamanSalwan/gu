#include <string>

#include "DaubState.h"
#include "Square.h"
#include "Exceptions.h"
#include "gtest/gtest.h"

TEST (TestSquare, FreeSquareConstructorTest) {
    Square *_square = new FreeSquare(21);
    EXPECT_EQ(_square->getValue(),0);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),true);
    delete _square;
    _square = nullptr;
}

TEST (TestSquare, FreeSquareDaubSquareTest) {
    Square* _square = new FreeSquare();

    _square->daubSquare(22);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),true);

    delete _square;
    _square = nullptr;
}

TEST(TestSquare, FreeSquareToStringTest) {
    Square* _square = new FreeSquare();
    EXPECT_EQ(_square->toString(),"free");
    delete _square;
    _square = nullptr;
}

TEST(TestSquare, FreeSquareResetSquareTest) {
    Square* _square = new FreeSquare(21);
    _square->resetSquare();

    EXPECT_EQ(_square->getDaubState()->isCorrect(), true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(), true);
    delete _square;
    _square = nullptr;
}

TEST(TestSquare, FreeSquareShouldDaubSquareTest) {
    Square* _square = new FreeSquare(12);
    _square->shouldDaubSquare(15);

    EXPECT_EQ(_square->getDaubState()->isCorrect(), true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(), true);
    delete _square;
    _square = nullptr;
}

TEST (TestSquare, IntSquareConstructorTest) {
    Square *_square = new IntSquare(21);
    EXPECT_EQ(_square->getValue(),21);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),false);
    delete _square;
    _square = nullptr;
}

TEST (TestSquare, IntSquareDaubSquareTest) {
    Square *_square = new IntSquare(21);
    
    _square->daubSquare(22);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),false);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),true);

    _square->daubSquare(21);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),true);

    delete _square;
    _square = nullptr;
}

TEST (TestSquare, IntSquareShouldDaubSquareTest ) {
    Square *_square = new IntSquare(10);
    
    //Initial checks for equal _value and not daubed
    _square->shouldDaubSquare(10);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),false);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),false);
    delete _square;
    
    //Check for different number daub state does not change
    _square = new IntSquare(11);
    _square->shouldDaubSquare(1);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),false);
    delete _square;


    //For already daubed for goodDaub
    _square = new IntSquare(11);
    _square->daubSquare(11);
    _square->shouldDaubSquare(11);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),true);
    delete _square;

    //For already daubed for badDaub
    _square = new IntSquare(11);
    _square->daubSquare(11);
    _square->shouldDaubSquare(1);
    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),true);
    delete _square;
    _square = nullptr;
}

TEST ( TestSquare, IntSquareToStringTest ) {
    Square *_square = new IntSquare(1);

    EXPECT_EQ(_square->toString()," 01 ");

    _square->daubSquare(1);

    EXPECT_EQ(_square->toString(),"(01)");

    delete _square;
    _square = new IntSquare(11);

    EXPECT_EQ(_square->toString()," 11 ");

    _square->daubSquare(11);

    EXPECT_EQ(_square->toString(),"(11)");
    delete _square;
    _square = nullptr;
}

TEST(TestSquare, IntSquareResetSquareTest) {
    Square* _square = new IntSquare(10);
    _square->resetSquare();

    EXPECT_EQ(_square->getDaubState()->isCorrect(),true);
    EXPECT_EQ(_square->getDaubState()->isDaubed(),false);

    delete _square;
    _square = nullptr;
}