#include "DaubState.h"
#include "Exceptions.h"
#include "gtest/gtest.h"

TEST(TestDaubState, GoodDaubTest) {
    DaubState* _daub = new GoodDaub();
    EXPECT_EQ(_daub->isCorrect(),true);
    EXPECT_EQ(_daub->isDaubed(),true);
    delete _daub;
    _daub = nullptr;
}

TEST(TestDaubState, NeedsDaubTest) {
    DaubState* _daub = new NeedsDaub();
    EXPECT_EQ(_daub->isCorrect(),false);
    EXPECT_EQ(_daub->isDaubed(),false);
    delete _daub;
    _daub = nullptr;
}

TEST(TestDaubState, BadDaubTest) {
    DaubState* _daub = new BadDaub();
    EXPECT_EQ(_daub->isCorrect(),false);
    EXPECT_EQ(_daub->isDaubed(),true);
    delete _daub;
    _daub = nullptr;
}

TEST(TestDaubState, NoDaubTest) {
    DaubState* _daub = new NoDaub();
    EXPECT_EQ(_daub->isCorrect(),true);
    EXPECT_EQ(_daub->isDaubed(),false);
    delete _daub;
    _daub = nullptr;
}

