#include <string>
#include <vector>

#include "gtest/gtest.h"
#include "BingoTypes.h"
#include "VictoryCondition.h"
#include "Square.h"

TEST(TestAnyLine, constructionTest) {
  VictoryCondition* victory = new AnyLine();

  std::string expectedDesc = "Daub five squares in a horizontal, vertical or diagonal line.";
  
  EXPECT_EQ(victory->getDescription(), expectedDesc);
  EXPECT_EQ(victory->getVictoryType(), BingoTypes::ANY_LINE);

  delete victory;
}

TEST(TestAnyLine, hasWonAnyLineHorizontalTest) {
  VictoryCondition* victory = new AnyLine();
  std::vector<Square*> grid;
  for(int i = 0 ;i < 25;i++) {
    if(i == 12 ) grid.push_back(new FreeSquare());
    else grid.push_back(new IntSquare(i+1));
  }
  for(int i = 10;i<14;i++){
    grid[i]->daubSquare(i+1);
  }
  EXPECT_EQ(victory->hasWon(grid),false);

  for(int i = 0;i<4;i++){
    grid[5*i]->daubSquare(5*i+1);
  }

  EXPECT_EQ(victory->hasWon(grid),false);
  grid[20]->daubSquare(21);
  EXPECT_EQ(victory->hasWon(grid),true);
  for(auto i : grid) delete i;
  delete victory;
}

/*TEST(TestAnyLine, hasWonAnyLineVerticalTest) {
    std::vector<Square*> grid;
  for(int i = 0 ;i < 25;i++) {
    if(i == 12 ) grid.push_back(new FreeSquare());
    else grid.push_back(new IntSquare(i+1));
  }
  for(int i = 10;i<14;i++){
    grid[i]->daubSquare(i+1);
  }

  VictoryCondition* victory = new AnyLine();
  EXPECT_EQ(victory->hasWon(grid),false);

  grid[14]->daubSquare(16);
  EXPECT_EQ(victory->hasWon(grid),false);
  grid[14]->daubSquare(15);
  EXPECT_EQ(victory->hasWon(grid),true);
  delete victory;

  for(auto i : grid) {
    delete i;
    i = nullptr;
  }
  grid.clear();
}*/

TEST(TestAnyLine, hasWonAnyLineRightDiagonalTest) {
    VictoryCondition* victory = new AnyLine();
    std::vector<Square*> grid;
    for(int i = 0 ;i < 25;i++) {
      if(i == 12 ) grid.push_back(new FreeSquare());
      else grid.push_back(new IntSquare(i+1));
    }
    EXPECT_EQ(victory->hasWon(grid),false);
    for(int i = 0;i<4;i++) {
        grid[i*6]->daubSquare(i*6+1);
    }
    grid[24]->daubSquare(25);
    EXPECT_EQ(victory->hasWon(grid),true);

    for(auto i : grid) {
        delete i;
        i = nullptr;
    }
    delete victory;
}

TEST(TestAnyLine, hasWonAnyLineLeftDiagonalTest) {
    VictoryCondition* victory = new AnyLine();
    std::vector<Square*> grid;
    for(int i = 0 ;i < 25;i++) {
      if(i == 12 ) grid.push_back(new FreeSquare());
      else grid.push_back(new IntSquare(i+1));
    }
    EXPECT_EQ(victory->hasWon(grid),false);
    
    for(int i = 1;i<=5;i++) {
        grid[i*4]->daubSquare(i*4+1);
    }
    EXPECT_EQ(victory->hasWon(grid),true);

    for(auto i : grid) {
        delete i;
        i = nullptr;
    }
    delete victory;
}
